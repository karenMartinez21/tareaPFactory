/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package patronfactory;

import java.util.Scanner;
/**
 *
 * @author Admin
 */
public class PatronFactory {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int eleccion = 0;
        
        //se pinta el menu
        System.out.println("¿Que articulo deseas comprar?");
        System.out.println("1- Computadora gamer");
        System.out.println("2- Computadora de oficina");
        System.out.println("3- Smartphone apple");
        System.out.println("4- Smartphone motorola");
        System.out.println("5- Tablet samsumg");
        System.out.println("6- Tablet huawei");
        
        try {
            System.out.print("Elige el numero:");
            eleccion = teclado.nextInt();
        } catch (Exception e) {
            System.out.println("No capturaste el numero");
        }
        
        switch (eleccion) {
            case 1:
                Computadora c = new Computadora("para jugar",false, true, true);
                System.out.println(c);
                break;
            case 2:
                Computadora co = new Computadora("para trabajar",true, true, false);
                System.out.println(co);
                break;
        
             case 3:
                Smartphone s = new Smartphone("apple",true, false, true,true);
                System.out.println(s);
                break;
            case 4:
                Smartphone sm = new Smartphone("motorola",true, true, false,true);
                System.out.println(sm);
                break;
                
            case 5:
                Tablet t = new Tablet("samsumg",true, true, true,true);
                System.out.println(t);
                break; 
             case 6:
                Tablet ta = new Tablet("huawei",false, true, true,true);
                System.out.println(ta);
                break;
                
            default:
                throw new AssertionError();
        }
    }
    
}
