/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patronfactory;

import ico.fes.factory.Articulo;

/**
 *
 * @author Admin
 */
public class Smartphone implements Articulo{
    String nombreMarca;
    boolean camara;
    boolean memoria;
    boolean pantalla;
    boolean modelo;

    public Smartphone() {
    }

    public Smartphone(String nombreMarca, boolean camara, boolean memoria, boolean pantalla, boolean modelo) {
        this.nombreMarca = nombreMarca;
        this.camara = camara;
        this.memoria = memoria;
        this.pantalla = pantalla;
        this.modelo = modelo;
    }

    public String getNombreMarca() {
        return nombreMarca;
    }

    public void setNombreMarca(String nombreMarca) {
        this.nombreMarca = nombreMarca;
    }

    public boolean isCamara() {
        return camara;
    }

    public void setCamara(boolean camara) {
        this.camara = camara;
    }

    public boolean isMemoria() {
        return memoria;
    }

    public void setMemoria(boolean memoria) {
        this.memoria = memoria;
    }

    public boolean isPantalla() {
        return pantalla;
    }

    public void setPantalla(boolean pantalla) {
        this.pantalla = pantalla;
    }

    public boolean isModelo() {
        return modelo;
    }

    public void setModelo(boolean modelo) {
        this.modelo = modelo;
    }

    @Override
    public String toString() {
        return "Smartphone{" + "nombreMarca=" + nombreMarca + ", camara=" + camara + ", memoria=" + memoria + ", pantalla=" + pantalla + ", modelo=" + modelo + '}';
    }

    
}
