/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ico.fes.factory;

import patronfactory.Computadora;
import patronfactory.Smartphone;
import patronfactory.Tablet;

/**
 *
 * @author Admin
 */
public class artiFactory {
    public static Articulo createArticulo(int tipo){
        switch (tipo) {
            case Articulo.COMPU_GAM:
                    return new Computadora("para jugar",false,true,true);
            case Articulo.COMPU_OF:
                    return new Computadora("para trabajar",true, true, false);
            case Articulo.SMA_APP:
                    return  new Smartphone("apple",true, false, true,true);
            case Articulo.SMA_MOT:
                    return new Smartphone("motorola",true, true, false,true);
            case Articulo.TAB_SAM:
                    return new Tablet("samsumg",true, true, true,true);
            case Articulo.TAB_HUA:
                    return  new Tablet("huawei",false, true, true,true);
                
            default:
                throw new AssertionError();
        }
    }
}
