/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patronfactory;

import ico.fes.factory.Articulo;

/**
 *
 * @author Admin
 */
public class Tablet implements Articulo{
    String marca;
    boolean sistemaOperativo;
    boolean color;
    boolean memoria;
    boolean dimension;

    public Tablet() {
    }

    public Tablet(String marca, boolean sistemaOperativo, boolean color, boolean memoria, boolean dimension) {
        this.marca = marca;
        this.sistemaOperativo = sistemaOperativo;
        this.color = color;
        this.memoria = memoria;
        this.dimension = dimension;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public boolean isSistemaOperativo() {
        return sistemaOperativo;
    }

    public void setSistemaOperativo(boolean sistemaOperativo) {
        this.sistemaOperativo = sistemaOperativo;
    }

    public boolean isColor() {
        return color;
    }

    public void setColor(boolean color) {
        this.color = color;
    }

    public boolean isMemoria() {
        return memoria;
    }

    public void setMemoria(boolean memoria) {
        this.memoria = memoria;
    }

    public boolean isDimension() {
        return dimension;
    }

    public void setDimension(boolean dimension) {
        this.dimension = dimension;
    }

    @Override
    public String toString() {
        return "Tablet{" + "marca=" + marca + ", sistemaOperativo=" + sistemaOperativo + ", color=" + color + ", memoria=" + memoria + ", dimension=" + dimension + '}';
    }
    
    
}
