/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patronfactory;

import ico.fes.factory.Articulo;

/**
 *
 * @author Admin
 */
public class Computadora implements Articulo {
    String caracteristicaPrincipal;
    boolean procesador;
    boolean memoria;
    boolean discoDuro;
    
        public Computadora(){
        }

        public Computadora(String caracteristicaPrincipal, boolean procesador, boolean memoria, boolean discoDuro) {
            this.caracteristicaPrincipal = caracteristicaPrincipal;
            this.procesador = procesador;
            this.memoria = memoria;
            this.discoDuro = discoDuro;
        }

    public String getCaracteristicaPrincipal() {
        return caracteristicaPrincipal;
    }

    public void setCaracteristicaPrincipal(String caracteristicaPrincipal) {
        this.caracteristicaPrincipal = caracteristicaPrincipal;
    }

    public boolean isProcesador() {
        return procesador;
    }

    public void setProcesador(boolean procesador) {
        this.procesador = procesador;
    }

    public boolean isMemoria() {
        return memoria;
    }

    public void setMemoria(boolean memoria) {
        this.memoria = memoria;
    }

    public boolean isDiscoDuro() {
        return discoDuro;
    }

    public void setDiscoDuro(boolean discoDuro) {
        this.discoDuro = discoDuro;
    }

    @Override
    public String toString() {
        return "Computadora{" + "caracteristicaPrincipal=" + caracteristicaPrincipal + ", procesador=" + procesador + ", memoria=" + memoria + ", discoDuro=" + discoDuro + '}';
    }
        
        
}


