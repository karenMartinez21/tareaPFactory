/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ico.fes.factory;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class test {
    public static void main(String[] args) {
          Scanner teclado = new Scanner(System.in);
        int eleccion = 0;
        
        //se pinta el menu
        System.out.println("¿Que articulo deseas comprar?");
        System.out.println(Articulo.COMPU_GAM+"- Computadora gamer");
        System.out.println(Articulo.COMPU_OF+"- Computadora de oficina");
        System.out.println(Articulo.SMA_APP+"- Smartphone apple");
        System.out.println(Articulo.SMA_MOT+"- Smartphone motorola");
        System.out.println(Articulo.TAB_SAM+"- Tablet samsumg");
        System.out.println(Articulo.TAB_HUA+"- Tablet huawei");
        
        try {
            System.out.print("Elige el numero:");
            eleccion = teclado.nextInt();
        } catch (Exception e) {
            System.out.println("No capturaste el numero");
        }
        
        Articulo electronica = artiFactory.createArticulo(eleccion);
        System.out.println(electronica.toString());
    }
}
