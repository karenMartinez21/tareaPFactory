/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ico.fes.factory;

/**
 *
 * @author Admin
 */
public interface Articulo {
    public static final int COMPU_GAM = 1;
    public static final int COMPU_OF = 2;
    public static final int SMA_APP = 3;
    public static final int SMA_MOT = 4;
    public static final int TAB_SAM = 5;
    public static final int TAB_HUA = 6;
    
    
    
}
